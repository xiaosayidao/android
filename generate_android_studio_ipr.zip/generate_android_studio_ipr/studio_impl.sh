#!/bin/bash -
#===============================================================================
#
#          FILE: studio_impl.sh
#
#         USAGE: ./studio_impl.sh
#
#   DESCRIPTION: 请在Android源码根目录执行.
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: tanfuhai (), tanfkey@gmail.com
#  ORGANIZATION:
#       CREATED: 07/28/2016 01:56:09 PM CST
#      REVISION:  ---
#===============================================================================

#set -o nounset                              # Treat unset variables as an error


script_dir=`cd \`dirname $0\`; pwd`

IDEGEN_JAR_PATH="`pwd`/out/host/linux-x86/framework"

if [ -d $IDEGEN_JAR_PATH ]; then
    echo "exist idepath"
else
    mkdir -p "$IDEGEN_JAR_PATH"
fi
#echo " script dir $script_dir"
cp $script_dir/idegen.jar -t $IDEGEN_JAR_PATH
cp $script_dir/excluded-paths -t `pwd`
source build/envsetup.sh
if [ -f $IDEGEN_JAR_PATH/idegen.jar ] ;then
    echo "start ide gen"
    development/tools/idegen/idegen.sh
else
    echo "please copy idegen.jar to $IDEGEN_JAR_PATH"
fi
